﻿namespace PayPal.Api
{
    /// <summary>
    /// Defines an interface for a PayPal JSON-serializable object.
    /// </summary>
    public interface IPayPalSerializableObject
    {
        /// <summary>
        /// Converts this object to a JSON string.
        /// </summary>
        /// <returns>A JSON-formatted string.</returns>
        string ConvertToJson();
    }
}
